<?php
// may not be needed, test during code cleanup
//session_start();
// $_SESSION["position_id"] = NULL;
// $_SESSION["member_id"] = NULL;
// echo '<pre>';
//     print_r($_SESSION);
//     echo '</pre>';
include "include/functions.php";
// Connect to MySQL database
$pdo = pdo_connect_mysql();

$query = "SELECT * FROM members
	LEFT JOIN silent_key
	ON silent_key.member_id = members.member_id
	WHERE members.callsign LIKE '%/sk'
	ORDER 
	BY silent_key.passed DESC, members.surname";

$stmt = $pdo->prepare($query);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?= template_header("Update Silent Key Roster") ?>

<div class="content read">
	<h2>Update Silent Key Roster</h2>
	<p>Click the arrow icon in the <b>Select</b> column that is on the row of the posistion you are updating...</p>
	<table>
        <thead>
            <tr>
		<td>&nbsp;</td>
                <td>First name</td>
                <td>Last name</td>
                <td>Call</td>
                <td>Born</td>
                <td>SK</td>
                <td>Select</td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
            <tr>
                <td hidden ><?= $member["member_id"] ?></td>
                <td hidden ><?= $member["sk_id"] ?></td>
		<td>&nbsp</td>
                <td><?= $member["forename"] ?></td>
                <td><?= $member["surname"] ?></td>
                <td><?= $member["callsign"] ?></td>
                <td><?= $member["born"] ?></td>
                <td><?= $member["passed"] ?></td>
                <td class="actions">
                    <a href="silent_key_update.php?sk_call=<?= $member[
                        "callsign"
                    ] ?>" class="edit">Select</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= template_footer() ?>

