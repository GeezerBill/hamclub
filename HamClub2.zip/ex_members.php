<?php
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Get the page via GET request (URL param: page), if non exists default the page to 1
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
// Number of records to show on each page
$records_per_page = 100;
// Prepare the SQL statement and get records from our members table, LIMIT will determine the page
$query = "SELECT * FROM members 
	WHERE `expiredate` < date_add(curdate(), interval -12 month) order by surname, forename";
// exclude members who have lapsed memberships more than three months outdated
$stmt = $pdo->prepare($query);
$stmt->bindValue(':current_page', ($page-1)*$records_per_page, PDO::PARAM_INT);
$stmt->bindValue(':record_per_page', $records_per_page, PDO::PARAM_INT);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of members, this is so we can determine whether there should be a next and previous button
$num_members = $pdo->query('SELECT COUNT(*) FROM members')->fetchColumn();
// pick up the style sheets used in the rest of the app, because we dont use a staddard header here
print '<link href="include/style.css" rel="stylesheet" type="text/css">';
print '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">';

print '<div class="content read">';

print "<table>"; 
print "<tr><td>Call</td>";
print "<td>First</td>";
print "<td>Last</td>";
print "<td>Expired</td>";
print "</tr>";

$numrows=0;

// Set up the alternating colors
$color1           = "ffffff";
$color2           = "99ccff";
$background_color = $color1;

foreach ($pdo->query($query) as $row) {
    if ($background_color == $color1) {
        $background_color = $color2;
    } else {
        $background_color = $color1;
    }
   	
    print "<tr bgcolor=\"$background_color\">";

    print "<td> <a title = 'QRZ.com lookup' href=http://www.qrz.com/db/$row[callsign] target=_blank> $row[callsign]</a></td>
                <td>$row[forename]</td>";
    print "<td> <a title = 'Member details' href=memberdetail.php?id=$row[member_id] target=_blank> $row[surname] </a></td>";
    print "<td>$row[expiredate]</td></tr>\n";
	$numrows++;
}

print "</table>";
print "</p>";
print "</div>";
//pdo close connection
$query = null; //may not be needed
$pdo = null;

?> 
