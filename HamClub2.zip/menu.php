<?php
include 'include/functions.php';
// Home Page template below.
?>

<?=template_header('Home')?>

<div class="content">
	<h2>Home</h2>
</div>
<div class="content h2">
<p>Reports</p>
</div>
<div class="body">
<table>
	<tr>
		<td>Administrative Reports</td><td>Website Reports</td>
	</tr>
<tr>
	<td>
<ul>
	<li><p><a href="arrl_report.php">ARRL Membership Report</a></p></li>
        <li><p><a href="renew_bulk.php">Renewal Notices</a></p></li>
        <li><p><a href="newsdist_bulk.php">Newsletter distribution by email</a></p></li>
        <li><p><a href="email_blast_bulk.php">Email blast to membership</a></p></li>
        <li><p><a href="roster_dump.php" target="self">Club roster export(spreadsheet)</a></p></li>
	<li><p><a href="table_dump.php" target="self">Database export (spreadsheet}</a></p></li>
</ul>
</td>
        <td>
<ul>
        <li><p><a href="rpt_selector.php" target="blank">Report selector (website)</a></p></li>
        <li><p><a href="roster.php" target="blank">Membership Roster (website format)</a></p></li>
        <li><p><a href="committee_roster.php" target="blank">Committee Roster (website format)</a></p></li>
        <li><p><a href="rpt_cmte.php" target="blank">Repeater Committee (website format)</a></p></li>
        <li><p><a href="fd_cmte.php" target="blank">Field Day Committee (website format)</a></p></li>
        <li><p><a href="officer_roster.php" target="blank">Officer Roster (website format)</a></p></li>
        <li><p><a href="elmer_roster.php" target="blank">Elmers (website format)</a></p></li>
        <li><p><a href="silent_key_roster.php" target="blank">Silent Keys (website format)</a></p></li>
        <li><p><a href="arrl_web.php" target="blank">ARRL statistics (website format)</a></p></li>
        <li><p><a href="ex_members.php" target="blank">Former Member Roster (website format)</a></p></li>
</ul>
</td>
</tr>
</table>
</div>
<?=template_footer()?>
