<?php
?>
<html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta name="ROBOTS" content="NOINDEX,NOFOLLOW" />
<meta content="text/html; charset=us-ascii" http-equiv="Content-Type" /><title>NARS Member Info</title>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Google reCAPTCHA v3</title>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js?render=6LeF35oaAAAAAG_7DS2w8OQjhkRRapkJpRHtmDvn'></script>
<script src="https://www.google.com/recaptcha/api.js?render=your reCAPTCHA site key here"></script>

</script>
    <script>
        grecaptcha.ready(function () {
            grecaptcha.execute('6LeF35oaAAAAAG_7DS2w8OQjhkRRapkJpRHtmDvn', { action: 'contact' })
                .then(function (token) {
                var recaptchaResponse = document.getElementById('recaptchaResponse');
                console.log(recaptchaResponse)
                recaptchaResponse.value = token;
            });
        });
    </script>
</head>

<body>
<div class="container">
    <div class="row">
        <div class="panel panel-login">
            <div class="panel-heading">
                <div class="row">

                </div>
                <hr>
            </div>
            <div class="panel-body">
                <div class="row">
        <div class="col-md-6 col-md-offset-3">

                    <?php // Check if form was submitted:

                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$selection=$_POST['report'];
                        // Build POST request:
                        $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
                        $recaptcha_secret = '6LeF35oaAAAAAEcKZ1ZA9ol8aaAMzmlR0ggAV2fA';
                        $recaptcha_response = $_POST['recaptcha_response'];
//revise - insert user selection
                        // Make and decode POST request:
                        $recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
                        $recaptcha = json_decode($recaptcha);

                        if($recaptcha->success==true){
                            // Take action based on the score returned:
                            if ($recaptcha->score >= 0.6) {
//
 				include ($selection);
                                exit;
//
                                // Verified - send email
                            } else {
				echo 'suspected bot...';
                                echo '<pre>';
                                print_r($recaptcha);
                                echo '</pre>';
				echo "suspected bot...";
                                exit;
                                // Not verified - show form error
                            }
                        }else{ // there is an error /
                            ///  timeout-or-duplicate meaning you are submit the  form
                            echo 'error';
			    echo '<pre>';
                            print_r($recaptcha);
                            echo '</pre>';
                            exit;

                        }
                    }
                 ?>
                    <form id="report_select" method="post">
                        <div class="form-group">
<fieldset>
<legend>Select membership report</legend>
<label>Choose the report you need</label>
			<br>Press <b>Continue</b> to view the selected roster.
                         </div>
<input type="radio" name="report" id="mbr" value="roster.php" checked="checked" /> <label for="mbr">Membership roster</label><br>
<input type="radio" name="report" id="off" value="officer_roster.php" /> <label for="off">Officer roster</label><br>
<input type="radio" name="report" id="cmte" value="committee_roster.php" /> <label for="cmte">Committee roster</label><br>
<input type="radio" name="report" id="elmr" value="elmer_roster.php" /> <label for="elmr">Elmers</label><br>
<input type="radio" name="report" id="sk" value="silent_key_roster.php" /> <label for="sk">Silent Key roster</label><br>
                        <input type="hidden" value="" name="recaptcha_response" id="recaptchaResponse">

                        <button type="submit" class="btn btn-primary">Continue...</button>

                    </form>

                </div>
      </div>
      </div>
 </div>

</body>

</html>
