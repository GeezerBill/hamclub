<?php
session_start();
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// echo '<pre>';
// print_r($_SESSION);
// echo '</pre>';
$call = ''; // define it so no error
// call passed from silent key
// echo "getting call...";
if (!isset($_GET['born'])) {
    if (isset($_GET['sk_call'])) {
        $call = $_GET['sk_call'];
        $query = "SELECT * FROM members WHERE callsign = :call";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':call', $call);
        $stmt->execute();
        $row = $stmt->fetchAll(PDO::FETCH_BOTH);
        $mbr = $row['0']['member_id'];
        $call = $row['0']['callsign'];
        $_SESSION['sk_call'] = $call;
        $_SESSION['mbr_id'] = $mbr;
    } else {
        echo "member not found...";
//        echo '<pre>';
//        print_r($_POST);
//        echo '</pre>';
        print "<br><a href=silent_key.php>Press to continue...</a>";
    }
} else {
//    echo "inserting dates";
//    echo '<pre>';
//    print_r($_SESSION);
//    echo '</pre>';
    //
    // update or insert? if
    //
    $b_date = isset($_GET['born']) ? $_GET['born'] : "";
    $s_date = isset($_GET['sk']) ? $_GET['sk'] : '';
    $mbr = isset($_SESSION['mbr_id']) ? $_SESSION['mbr_id'] : '';

// handle no input on birthdate if unknown
    $b_date = strtotime($b_date) ? $b_date : NULL;
//
    $query = "SELECT * FROM silent_key WHERE member_id = $mbr";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $row = $stmt->fetchAll(PDO::FETCH_BOTH);
    if ($row) {
        // updating the existing record	$update = true;
        $id = $row['0']['sk_id'];
//        echo "Updating member # ", $mbr, " in SK roster.<br>";
//        echo $b_date, " # ", $s_date;
//        echo "  primary key ", $id;
        // update existing row
        $query = "UPDATE silent_key SET born=?, passed=? WHERE member_id=?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$b_date, $s_date, $mbr]); //working to here
        
    } else {
        // add row to silent_key
       $query = "INSERT INTO silent_key (member_id, born, passed)
		VALUES
		(:member_id, :born, :passed)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':member_id', $mbr);
        $stmt->bindParam(':born', $b_date);
        $stmt->bindParam(':passed', $s_date);
        $stmt->execute();
    }
    // echo '<pre>';
    //    print_r($row);
    //    echo '</pre>';
    // got the member and member id...
   echo '<a href="silent_key.php?>">Update complete...press to continue.</a>';
}
?>
<?=template_header('Silent Key') ?>
<div class="content read">

<h2>Add/Update Silent Key</h2>

<table>
   <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method ="get" >
	<tr><br>Enter birth date (if known) and SK date (required), and then press <b>Add</b>.<br>
	</tr>
	<tr>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><label for="call">Call</label></td>
		<td><label for="born">Born on</label></td>
		<td><label for="passed">SK date</label></td>
		<td><label for="add">Add</label></td>
	</tr>
	<tr>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><input type="text" name="call" value="<?php print $call; ?>"></td>
		<td><input type="date" name="born"></td>
		<td><input type="date" name="sk" value="" required></td>
		<td><input type="submit" value="Update"></td>	
	</tr>
</table>
</div>
<?=template_footer() ?>
