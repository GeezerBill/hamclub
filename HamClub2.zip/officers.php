<?php
// may not be needed, test during code cleanup
session_start();
$_SESSION["position_id"] = NULL;
$_SESSION["member_id"] = NULL;
//echo '<pre>';
//    print_r($_SESSION);
//    echo '</pre>';
//start with both pointers cleared...
include 'include/functions.php';
// Connect to MySQL database

// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Prepare the SQL statement and get records from our members table, LIMIT will determine the page

// get the current list of officers...
$query = "SELECT * FROM officers
	LEFT JOIN members
	ON officers.member_id = members.member_id";

$stmt = $pdo->prepare($query);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?=template_header('Update Officer Roster') ?>

<div class="content read">
	<h2>Update Officers</h2>
	<p>Click the arrow icon in the <b>Select</b> column that is on the row of the posistion you are updating...</p>
	<table>
        <thead>
            <tr>
                <td>Position</td>
                <td>First name</td>
                <td>Last name</td>
                <td>Call</td>
                <td>Phone</td>
                <td>Email</td>
                <td>Select</td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
            <tr>
                <td hidden><?=$member['member_id'] ?></td>
		<td><?=$member['position'] ?></td>
                <td hidden><?=$member['officer_id'] ?></td>
                <td><?=$member['forename'] ?></td>
                <td><?=$member['surname'] ?></td>
                <td><?=$member['callsign'] ?></td>
                <td><?=$member['phonepri'] ?></td>
                <td><?=$member['emailpers'] ?></td>
                <td class="actions">
                    <a href="officer_update.php?officer_id=<?=$member['officer_id'] ?>" class="edit">Select</a>
                </td>
            </tr>
            <?php
endforeach; ?>
        </tbody>
    </table>
</div>
<?=template_footer() ?>
