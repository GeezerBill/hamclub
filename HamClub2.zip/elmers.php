<?php
// may not be needed, test during code cleanup
session_start();
$_SESSION["position_id"] = NULL;
$_SESSION["member_id"] = NULL;
//echo '<pre>';
//    print_r($_SESSION);
//    echo '</pre>';
//start with both pointers cleared...
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// add the new position if requested
if (!empty($_POST)) {
	$position = isset($_POST['position']) ? $_POST['position'] : '';
	$stmt = $pdo->prepare('INSERT INTO elmers (position) VALUE (:position)');
	$stmt->execute([$position]);
}
// Prepare the SQL statement and get records from our members table, LIMIT will determine the page
// get the current list of elmers...
$query = "SELECT * FROM elmers
	LEFT JOIN members
	ON elmers.member_id = members.member_id ORDER BY position";

$stmt = $pdo->prepare($query);
$stmt->execute();

// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?=template_header('Update Elmer Roster') ?>

<div class="content read">
	<h2>Update Elmers</h2>
    <form action="elmers.php" method="post">
        <label for="elmer_pos">To create a new position, enter the title and press <b>Create</b></label>
          <input type="text" name="position" id="position" required>
        <input type="submit" value="Create">
	</form>
	<p>Click the arrow icon in the <b>Select</b> column that corresponds to row of the posistion you are updating...</p>
	
	<table>
        <thead>
            <tr>
                <td>Remove</td>
                <td>Topic</td>
                <td>First name</td>
                <td>Last name</td>
                <td>Call</td>
                <td>Phone</td>
                <td>Email</td>
                <td>Select</td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
            <tr>
                <td hidden><?=$member['member_id'] ?></td>
		<td class="actions"><a href="elmer_delete.php?elmer_id=<?=$member['elmer_id'] ?>" class="edit">Delete</a></td>
 		<td><?=$member['position'] ?></td>
                <td hidden><?=$member['elmer_id'] ?></td>
                <td><?=$member['forename'] ?></td>
                <td><?=$member['surname'] ?></td>
                <td><?=$member['callsign'] ?></td>
                <td><?=$member['phonepri'] ?></td>
                <td><?=$member['emailpers'] ?></td>
                <td class="actions">
                    <a href="elmer_update.php?elmer_id=<?=$member['elmer_id'] ?>" class="edit">Select</i></a>
                </td>
            </tr>
            <?php
endforeach; ?>
        </tbody>
    </table>

</div>
<?=template_footer() ?>
