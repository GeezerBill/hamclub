<?php
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Prepare the SQL statement and get records from our members table
$query = "SELECT * FROM members 
		WHERE `expiredate` > date_add(curdate(), interval -3 month) 
		AND `callsign` NOT LIKE '%/sk%'
		ORDER BY surname, forename";
// exclude members who have lapsed memberships more than three months outdated
$stmt = $pdo->prepare($query);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
// pick up the style sheets used in the rest of the app, because we dont use a standard header here

print '<link href="include/rpt-style.css" rel="stylesheet" type="text/css">';


print '<div class="content read">';

print "<table>";
print "<thead>"; 
print "<tr>Expiring memberships highlighted in yellow.</tr>";
print "<tr><td>Call</td>";
print "<td>First</td>";
print "<td>Last</td>";
print "<td>Expires</td>";
print "</tr>";
print "</thead>";

$numrows=0;

// Set up the alternating colors
$color1           = "ffffff";
$color2           = "99ccff";
$background_color = $color1;

foreach ($pdo->query($query) as $row) {

    $today = strtotime ("now");
    if (strtotime($row['expiredate']) < $today)  {
	$background_color = "ffcc00";
	} else {
	$background_color = $color1;
	}
   	
    print "<tr bgcolor=\"$background_color\">";

    print "<td> <a title = 'QRZ.com lookup' href=http://www.qrz.com/db/$row[callsign] target=_blank> $row[callsign]</a></td>
                <td>$row[forename]</td>";
    print "<td> <a title = 'Member details' href=memberdetail.php?id=$row[member_id] target=_blank> $row[surname] </a></td>";
    print "<td>$row[expiredate]</td></tr>\n";
	$numrows++;
}

print "</table>";
print "<p class = body> Current active membership: ";
echo $numrows;
print "</p>";
print "</div>";
//pdo close connection
$query = null; //may not be needed
$pdo = null;

?> 
