<?php
include 'include/functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// print_r($_GET);  // for all GET variables
$committee_idx = isset($_GET['position_id'])? $_GET['position_id']: 'committee_idx not passed '; 
$mbr_idx = isset($_GET['member_id'])? $_GET['member_id']: 'mbr_idx not passed ';

echo "updating committee ";
echo $committee_idx;
echo " with member # ";
echo $mbr_idx;

if (isset($_GET['member_id'])) {
    if (isset($_GET['position_id'])) {

        // Update the record
	$query = "UPDATE committees SET member_id = $mbr_idx  WHERE committee_id = $committee_idx";
	$stmt = $pdo->prepare($query);
        $res = $pdo->query($query);
	$msg = 'Updated Successfully!';

    }
} else {
    exit('No ID specified!');
}
?>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php endif; ?>
<a href="committee.php">Press to continue...</a>

<?=template_header('Updating committee information')?>

