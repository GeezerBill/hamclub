<?php
include 'include/functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// Check if the contact id exists, for example update.php?id=1 will get the contact with the id of 1
if (isset($_GET['member_id'])) {
    if (!empty($_POST)) {
        // This part is similar to the create.php, but instead we update a record and not insert
        $forename = isset($_POST['forename']) ? $_POST['forename'] : '';
        $surname = isset($_POST['surname']) ? $_POST['surname'] : '';
        $street = isset($_POST['street']) ? $_POST['street'] : '';
        $house = isset($_POST['house']) ? $_POST['house'] : '';
        $city = isset($_POST['city']) ? $_POST['city'] : '';
        $state = isset($_POST['state']) ? $_POST['state'] : '';
        $postcode = isset($_POST['postcode']) ? $_POST['postcode'] : '';
        $country = isset($_POST['country']) ? $_POST['country'] : '';
        $emailpers = isset($_POST['emailpers']) ? $_POST['emailpers'] : '';
        $emailalt = isset($_POST['emailalt']) ? $_POST['emailalt'] : '';
        $emailfail = isset($_POST['emailfail']) ? $_POST['emailfail'] : '';
        $phonepri = isset($_POST['phonepri']) ? $_POST['phonepri'] : '';
        $phonealt = isset($_POST['phonealt']) ? $_POST['phonealt'] : '';
        $phonework = isset($_POST['phonework']) ? $_POST['phonework'] : '';
        $showdetail = isset($_POST['showdetail']) ? $_POST['showdetail'] : '';
        $callsign = isset($_POST['callsign']) ? $_POST['callsign'] : '';
        $licclass = isset($_POST['licclass']) ? $_POST['licclass'] : '';
        $arrlmember = isset($_POST['arrlmember']) ? $_POST['arrlmember'] : '';
        $joindate = isset($_POST['joindate']) ? $_POST['joindate'] : '';
        $expiredate = isset($_POST['expiredate']) ? $_POST['expiredate'] : '';
        $duesdate = isset($_POST['duesdate']) ? $_POST['duesdate'] : '';
        $membertype = isset($_POST['membertype']) ? $_POST['membertype'] : '';
        $newsdist = isset($_POST['newsdist']) ? $_POST['newsdist'] : '';
        $duesamount = isset($_POST['duesamount']) ? $_POST['duesamount'] : '' ;
        $payment_by = isset($_POST['payment_by']) ? $_POST['payment_by'] : '';
        $duesreceived = isset($_POST['duesreceived']) ? $_POST['duesreceived'] : '';
        $notes = isset($_POST['notes']) ? $_POST['notes'] : '';

        // Update the record
        $stmt = $pdo->prepare('UPDATE members SET forename = ?, surname = ?, street = ?, house = ?, city = ?, 
				state = ?, postcode = ?, country = ?, emailpers = ?, emailalt = ?, emailfail = ?, phonepri = ?,
				phonealt = ?, phonework = ?, showdetail = ?, callsign = ?, licclass = ?, arrlmember = ?, 
				joindate = ?, expiredate = ?, duesdate = ?, membertype = ?, newsdist = ?, duesamount = ?, 
				payment_by = ?, duesreceived = ?, notes = ? WHERE member_id = ?');
        $stmt->execute([$forename, $surname, $street, $house, $city, $state, $postcode, $country, $emailpers, $emailalt, 
			$emailfail, $phonepri, $phonealt, $phonework, $showdetail, $callsign, $licclass, $arrlmember, $joindate, 
			$expiredate, $duesdate, $membertype, $newsdist, $duesamount, $payment_by, $duesreceived, $notes, $_GET['member_id']]);
        $msg = 'Updated Successfully!';
echo 'To send an acknowledgement, go to the <a href="#bottom">bottom of the page.</a>';
    }
    // Get the contact from the members table
    $stmt = $pdo->prepare('SELECT * FROM members WHERE member_id = ?');
    $stmt->execute([$_GET['member_id']]);
    $contact = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$contact) {
        exit('Contact doesn\'t exist with that ID!');
    }
} else {
    exit('No ID specified!');
}
?>

<?=template_header('Update')?>

<div class="content update">
	<h2>Updating membership information...</h2>
    <form action="update.php?member_id=<?=$contact['member_id']?>" method="post">
        <label for="id"><h2>Update member #</h2></label>
        <input type="text" name="id" placeholder="1" value="<?=$contact['member_id']?>" id="id">
        <label for="forename">First Name</label>
        <label for="surname">Last Name</label>
        <input type="text" name="forename" placeholder="John" value="<?=$contact['forename']?>" id="forename">
        <input type="text" name="surname" placeholder="John" value="<?=$contact['surname']?>" id="surname">
        <label for="sreet">Street address</label>
        <label for="house">Apt / PO Box</label>
        <input type="text" name="street" placeholder="1600 Pennsylvania Ave." value="<?=$contact['street']?>" id="street">
        <input type="text" name="house" placeholder="" value="<?=$contact['house']?>" id="house">
        <label for="city">City</label>
        <label for="state">State</label>
          <input type="text" name="city" placeholder="Austin" value="<?=$contact['city']?>" id="city">
          <input type="text" name="state" placeholder=" TX" value="<?=$contact['state']?>" id="state">
        <label for="postcode">Postal code</label>
        <label for="country">Country</label>
          <input type="text" name="postcode" placeholder="78701" value="<?=$contact['postcode']?>" id="postcode">
          <input type="text" maxlength='10' name="country" placeholder="USA" value="<?=$contact['country']?>" id="country">
        <label for="emailpers">Personal email</label>
        <label for="emailalt">Alternate email</label>
          <input type="email" name="emailpers" placeholder="johndoe@example.com" value="<?=$contact['emailpers']?>" id="emailpers">
          <input type="email" name="emailalt" placeholder="johndoe@example.com" value="<?=$contact['emailalt']?>" id="emailalt">
        <label for="emailfail">Email failed</label>
          <input type="text" maxlength='3' name="emailfail" placeholder="no" value="<?=$contact['emailfail']?>" id="emailfail">
        <label for="phonepri">Preferred phone #</label>
        <label for="phonealt">Alternate Phone #</label>
          <input type="tel" name="phonepri" placeholder="5123058524" value="<?=$contact['phonepri']?>" id="phonepri">
          <input type="tel" name="phonealt" placeholder="5124634630" value="<?=$contact['phonealt']?>" id="phonealt">
        <label for="phonework">Work phone</label>
        <label for="showdetail">Show personal details</label>
          <input type="tel" name="phonework" placeholder="5124630063" value="<?=$contact['phonework']?>" id="phonework">
          <input type="text" maxlength='3' name="showdetail" placeholde='no' value="<?=$contact['showdetail']?>" id="showdetail">
	<label for="callsign">Callsign</label>
        <label for="licclass">License class</label>
          <input type="text" name="callsign" placeholder="W5NC" value="<?=$contact['callsign']?>" id="callsign">
          <input type="text" name="licclass" placeholder="General" value="<?=$contact['licclass']?>" id="licclass">
        <label for="arrlmember">ARRL Member</label>
	<label for="joindate">Date joined</label>
          <input type="text" maxlength='3' name="arrlmember" placeholder="yes" value="<?=$contact['arrlmember']?>" id="arrlmember">
	  <input type="date" name="joindate" placeholder="2020-01-01" value="<?=$contact['joindate']?>" id="joindate">
        <label for="expiredate">Membership expires</label>
	<label for="duesdate">Renewed on</label>
          <input type="date" name="expiredate" placeholder="2020-01-01" value="<?=$contact['expiredate']?>" id="expiredate">
	  <input type="date" name="duesdate" placeholder="2020-01-01" value="<?=$contact['duesdate']?>" id="duesdate">
	<label for="membertype">Membership type</label>
	<label for="newsdist">Newsletter distribution preference</label>
          <input type="text" name="membertype" placeholder="member" value="<?=$contact['membertype']?>" id="membertype">
          <input type="text" maxlength='5' name="newsdist" placeholder="web" value="<?=$contact['newsdist']?>" id="newsdist">
	<label for="duesamount">Dues</label>
	<label for="payment_by">Payment by</label>
          <input type="number" name="duesamount" value="<?=$contact['duesamount']?>" min="0.00" step="5.00" id="duesamount">
	  <input type="text" name="payment_by" vallue="<?=$contact['payment_by']?>" list="pmtby" id="payment_by">
		<datalist id="pmtby">		
		<option>PayPal</option>
		<option>Check</option>
		<option>Cash</option>
		<option>Zelle</option>
		</datalist>
	<label for="duesreceived">Dues received</label>
	<label for="notes">Notes</label>
          <input type="number" name="duesreceived" placeholder="20.00" value="<?=$contact['duesreceived']?>" min="0.00" step="5.0" id="duesreceived">
          <input type="text" name="notes" placeholder="" value="<?=$contact['notes']?>" id="notes">

        <input type="submit" value="Update">
    </form>
<a id="bottom"></a>
<?php if ($msg) include 'dues_thanks_individual.php';?>
</div>
