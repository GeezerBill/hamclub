<?php
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// pick up the style sheet
print '<link href="include/style.css" rel="stylesheet" type="text/css">';
template_header('ARRL Membership Report');
//original code starts here;
print "<table border=1 cellpadding=1 cellspacing=1 width=780> \n";
//summary information...
// arrl members
$query = "SELECT * from members WHERE `expiredate` > date_add(curdate(), interval -3 month) 
		AND `callsign` NOT LIKE '%/sk%' 
		AND `arrlmember`=\"yes\" ";
$res = $pdo->query($query);
$row_count = $res->rowCount();
$arrl_members = $row_count;
// not arrl members
$query = "SELECT * from members WHERE `expiredate` > date_add(curdate(), interval -3 month) 
		AND `callsign` NOT LIKE '%/sk%' 
		AND `arrlmember`=\"no\" ";
$res = $pdo->query($query);
$row_count = $res->rowCount();
// do the arithmetic...
$non_members = $row_count;
$total = $arrl_members + $non_members;
$perc = round(($arrl_members / $total) * 100);
print "</table>";

// publish the stats

print "<table width=50%>";
print "<tr> <td colspan=3 align=center><br />&nbsp;<b>Summary Report</b><br />&nbsp;<br />ARRL members = $arrl_members<br />Non-members = $non_members<br />Total membership = $total<br />&nbsp;<br />$perc % of NARS members are also ARRL members<br />&nbsp;</td></tr>";
print "</table</>";
// list the arrl members
//arrl members
$query = "SELECT * FROM members WHERE `expiredate` > date_add(curdate(), interval -3 month) 
				AND `callsign` NOT LIKE '%/sk%'			
				AND `arrlmember`=\"yes\" order by surname,forename";
print '<div class="content read">';
print "<table width=50%>";
print "<tr> <td colspan=3 align=center><b>ARRL Members</b></td></tr>";
print "<tr> <td align=left><b>First name</b></td><td align=left><b>Last name</b></td><td align=left><b>Call</b></td></tr>";
foreach ($pdo->query($query) as $row) {
    print "<tr> <td align=left>$row[forename]</a></td><td align=left>$row[surname]</td><td align=left>$row[callsign]</td></tr>\n";
}
print "<tr> <td colspan=3 align=center>$arrl_members &nbsp;NARS members are ARRL members.</td></tr>\n";
//non-members
$query = "SELECT * FROM members WHERE `expiredate` > date_add(curdate(), interval -3 month) 
				AND `callsign` NOT LIKE '%/sk%'
				AND `arrlmember`=\"no\" order by surname,forename";
#print "$query\n<br>";
print "<tr> <td colspan=3 align=center><b>non-ARRL Members</b></td></tr>";
print "<tr> <td><b>Call</b></td><td><b>First</b></td><td><b>Last</b></td></tr>";
foreach ($pdo->query($query) as $row) {
    print "<tr> <td>$row[forename]</td><td>$row[surname]</td><td>$row[callsign]</td></tr>";
}
print "<tr> <td colspan=3 align=center>$non_members &nbsp;NARS members are not ARRL members.</td></tr>\n";
print "</table>";

//pdo close connection
$pdo = null;
?>
<?=template_footer('ARRL Membership') ?>
