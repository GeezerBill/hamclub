<?php
// may not be needed, test during code cleanup
session_start();
$_SESSION["position_id"] = NULL;
$_SESSION["member_id"] = NULL;
//echo '<pre>';
//    print_r($_SESSION);
//    echo '</pre>';
//start with both pointers cleared...
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Get the page via GET request (URL param: page), if non exists default the page to 1
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
// Number of records to show on each page
$records_per_page = 10;
// Prepare the SQL statement and get records from our members table, LIMIT will determine the page

// get the current list of officers...
$query = "SELECT * FROM officers
	LEFT JOIN members
	ON officers.member_id = members.member_id";

$stmt = $pdo->prepare($query);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of members, this is so we can determine whether there should be a next and previous button
$num_members = $pdo->query('SELECT COUNT(*) FROM members')->fetchColumn();
?>
<link href="include/rpt-style.css" rel="stylesheet" type="text/css">


<div class="content read">
	<table>
        <thead>
	<tr>All officers can be contacted at the group email address officers@w5nc.net in addition to the addresses listed below</td>
            <tr>
                <td>Position</td>
                <td>First name</td>
                <td>Last name</td>
                <td>Call</td>
                <td>Phone</td>
                <td>Email</td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
            <tr>
                <td hidden><?=$member['member_id'] ?></td>
		<td><?=$member['position'] ?></td>
                <td hidden><?=$member['officer_id'] ?></td>
                <td><?=$member['forename'] ?></td>
                <td><?=$member['surname'] ?></td>
                <td><?=$member['callsign'] ?></td>
                <td><?=$member['phonepri'] ?></td>
                <td><?=$member['emailpers'] ?></td>
            </tr>
            <?php
endforeach; ?>
        </tbody>
    </table>
</div>
