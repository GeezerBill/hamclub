<?php
// may not be needed, test during code cleanup
session_start();
$_SESSION["position_id"] = NULL;
$_SESSION["member_id"] = NULL;
//echo '<pre>';
//    print_r($_SESSION);
//    echo '</pre>';
//start with both pointers cleared...
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// selecting the repeater entries
$query = "SELECT * FROM committees
	LEFT JOIN members
	ON committees.member_id = members.member_id 
    WHERE position like '%repeater%'
    ORDER BY position";
$stmt = $pdo->prepare($query);
$stmt->execute();
// Fetch the records...
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<link href="include/rpt-style.css" rel="stylesheet" type="text/css">
<div class="content read">
<p>The following members are responsible for repeater maintenance and operation.</p>
	<table>
        <thead>
            <tr>
                <td>Topic</td>
                <td>First name</td>
                <td>Last name</td>
                <td>Call</td>
                <td>Phone</td>
                <td>Email</td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
            <tr>
                <td hidden><?=$member['member_id'] ?></td>
		<td><?=$member['position'] ?></td>
                <td hidden><?=$member['committee_id'] ?></td>
                <td><?=$member['forename'] ?></td>
                <td><?=$member['surname'] ?></td>
                <td><?=$member['callsign'] ?></td>
                <td><?=$member['phonepri'] ?></td>
                <td><?=$member['emailpers'] ?></td>
            <?php
endforeach; ?>
        </tbody>
    </table>
</div>
