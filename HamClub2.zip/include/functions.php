<?php
function pdo_connect_mysql() {
    $DATABASE_HOST = 'localhost';
    $DATABASE_USER = 'club2021';
    $DATABASE_PASS = 'Wisky5nCharly';
    $DATABASE_NAME = 'club2021';
// remove array(... and uncomment try - catch  for production version
//    try {
    	return new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME . ';charset=utf8', $DATABASE_USER, $DATABASE_PASS,
          array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    		PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC));
//    } catch (PDOException $exception) {
    	// If there is an error with the connection, stop the script and display the error.
    	exit('Failed to connect to database!');
//    }
}
function template_header($title) {
echo <<<EOT
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>$title</title>
		<link href="include/style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body>
    <nav class="navtop">
    	<div>
    		<h1>&nbsp;Membership Maintenance</h1>
            <a href="menu.php"><i class="fas fa-home"></i>Home</a>
            <a href="locate.php">Update Member</a>
            <a href="create.php">Add Member</a>
    	    <a href="committee.php">Update Committees&nbsp;</a>
    	    <a href="officers.php">Update Officers&nbsp;</a>
    	    <a href="elmers.php">Update Elmers&nbsp;</a>
    	    <a href="silent_key.php">Update Silent&nbsp;Key&nbsp;</a>
    	</div>
    </nav>
EOT;
}
function template_footer() {
<<<EOT
NARS Membership Managment System
Northwest Amateur Radio Society
Houston, TX 
April 2021 V1.0
    </body>
</html>
EOT;
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
