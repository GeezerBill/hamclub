<?php
// part of hamclub2 - march 2021
// exports current membership roster as Excel spreadsheet
// writes membership table to spreadsheet

header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=roster.xls");
header("Pragma: no-cache");
header("Expires: 0");

include "include/functions.php";
$pdo = pdo_connect_mysql();
$c_count = 0;
// column headings
print "<table border=0 cellpadding=1 cellspacing=1 > \n";
print "<tr>";

	print "<td>Call</td><td>First name</td><td>Last name</td><td>Address 1</td><td>Address 2</td><td>City</td><td>State</td>
		<td>ZIP</td><td>Country</td><td>Personal email</td><td>Alt email</td>
		<td>Primary phone</td><td>Alternate phone</td><td>Work phone</td>";

print "</tr>";

// now each row in the database 

$query="SELECT callsign, forename, surname, street, house, city, state, postcode, country, emailpers, emailalt, phonepri, phonealt, phonework
        FROM members 
	WHERE `expiredate` > date_add(curdate(), interval -3 month) AND `callsign` NOT LIKE '%/sk%' order by surname, forename";

$stmt = $pdo->prepare($query);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($members as $member)
        {
        print "<tr>";
	print "<td>" . $member['callsign'] . "</td>";
	print "<td>" . $member['forename'] . "</td>";
	print "<td>" . $member['surname'] . "</td>";
	print "<td>" . $member['street'] . "</td>";
	print "<td>" . $member['house'] . "</td>";
	print "<td>" . $member['city'] . "</td>";
	print "<td>" . $member['state'] . "</td>";
	print "<td>" . $member['postcode'] . "</td>";
	print "<td>" . $member['country'] . "</td>";
	print "<td>" . $member['emailpers'] . "</td>";
	print "<td>" . $member['emailalt'] . "</td>";
	print "<td>" . $member['phonepri'] . "</td>";
	print "<td>" . $member['phonealt'] . "</td>";
	print "<td>" . $member['phonework'] . "</td>";

        print "</tr>\n";
}

print "<tr> <td> ";
print "Data current as of ";
$today = date("F j, Y");
print "$today";
print "</td> </tr>\n";
print "</table>";
//pdo close connection
$rs = null;
$query = null; //may not be needed
$dbh = null;
