<?php
// part of hamclub2 - march 2021
// exports current membership roster as Excel spreadsheet
// writes membership table to spreadsheet

header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=members.xls");
header("Pragma: no-cache");
header("Expires: 0");

include "include/functions.php";
$pdo = pdo_connect_mysql();
$c_count = 0;
// column headings
print "<table border=0 cellpadding=1 cellspacing=1 > \n";
print "<tr>";
//here we are getting the names of the fields for column names
$row = $pdo->query('SELECT * FROM members LIMIT 0');
for ($i = 0; $i < $row->columnCount(); $i++) {
        $col = $row->getColumnMeta($i);
        $columns[] = $col['name'];
        print "<td> $columns[$i] </td>";
        $c_count++;
}
print "</tr>";

// now each row in the database 

$query="SELECT * FROM members WHERE 1 ORDER BY surname, forename";

foreach ($pdo->query($query) as $row)
        {
        print "<tr>";
	for ($i = 0; $i < $c_count; $i++) {
		$c_name = $columns[$i];
                print "<td>$row[$c_name]</td>";
                }
        print "</tr>\n";
}

print "<tr> <td> ";
print "Data current as of ";
$today = date("F j, Y");
print "$today";
print "</td> </tr>\n";
print "</table>";
//pdo close connection
$rs = null;
$query = null; //may not be needed
$dbh = null;
