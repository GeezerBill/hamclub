<?php
$file_name = "email_body/renewal_response_individual.txt";
($message_file = fopen($file_name, "r")) or die("Unable to open file!");
$message = fread($message_file, filesize($file_name));
// tell who the message is going to
$email = $_POST['emailpers'];
$first_name = $_POST['forename'];
$hamcall = $_POST['callsign'];
$pmt_by = $_POST['payment_by'];
$pmt_amount = $_POST['duesreceived'];
$ccemail = 'officers@w5nc.net';
$subj = 'Welcome to NARS'.' '.$hamcall;
$crlf = '%0D%0A';
$current_date = date("l, d M Y");
$addr_head = 'Northwest Amateur Radio Society%0D%0AP.O. Box 11483%0D%0ASpring, Texas 77391';
$mast_head = $current_date.$crlf.$addr_head.$crlf;
$pre = 'Hello '.$first_name.' ('.$hamcall.'):'.$crlf;
// tell who the message is going to

$pre =
    "Hello " .
    $first_name .
    " (" .
    $hamcall .
    "):" .
    $crlf .
    "Thank you for your payment by " .
    $pmt_by .
    " in the amount of " .
    $pmt_amount .
    ". ";
$fixed_body = htmlspecialchars($message);
$msg_body = $mast_head . $crlf . $pre . $crlf . $fixed_body;

echo <<<EOL
                    
<a href="mailto:$email?cc=$ccemail&subject=$subj&body=$msg_body">Send thank you email to $first_name</a>
<br>
<a href="renew_bulk.php">Continue...</a>
EOL;
fclose($message_file);
?>


