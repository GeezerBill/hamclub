<?php
// may not be needed, test during code cleanup
session_start();
//echo '<pre>';
//    print_r($_SESSION);
//    echo '</pre>';
//start with both pointers cleared...
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Prepare the SQL statement and get records from our members table, LIMIT will determine the page

// get the current list of officers...
$query = "SELECT * FROM members
	LEFT JOIN silent_key
	ON silent_key.member_id = members.member_id
	WHERE members.callsign LIKE '%/sk'
	ORDER BY silent_key.passed DESC, members.surname";

$stmt = $pdo->prepare($query);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of members, this is so we can determine whether there should be a next and previous button
$num_members = $pdo->query('SELECT COUNT(*) FROM members')->fetchColumn();
?>
<link href="include/rpt-style.css" rel="stylesheet" type="text/css">


<div class="content read">
	<table>
        <thead>
	<tr>This page is dedicated to club members who no longer answer CQs. Thank you for sharing a part of your life with us.</td>
            <tr>
                <td>First name</td>
                <td>Last name</td>
                <td>Call</td>
                <td>Born</td>
                <td>SK</td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
            <tr>
                <td hidden><?=$member['member_id'] ?></td>
		<td hidden><?=$member['sk_id'] ?></td>
                <td><?=$member['forename'] ?></td>
                <td><?=$member['surname'] ?></td>
                <td><?=$member['callsign'] ?></td>
                <td><?=$member['born'] ?></td>
                <td><?=$member['passed'] ?></td>
            </tr>
            <?php
endforeach; ?>
        </tbody>
    </table>
</div>
