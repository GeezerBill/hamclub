<?php
?>
<html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta name="ROBOTS" content="NOINDEX,NOFOLLOW" />
<meta content="text/html; charset=us-ascii" http-equiv="Content-Type" /><title>W5NC Stats</title>
</html>

<?php
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// pick up the style sheet
print '<link href="include/style.css" rel="stylesheet" type="text/css">';
// template_header('ARRL Membership Report');

//original code starts here;

//summary information...
// arrl members
$query = "SELECT * from members WHERE `expiredate` > date_add(curdate(), interval -3 month) 
		AND `callsign` NOT LIKE '%/sk%' 
		AND `arrlmember`=\"yes\" ";
$res = $pdo->query($query);
$row_count = $res->rowCount();
$arrl_members = $row_count;
// not arrl members
$query = "SELECT * from members WHERE `expiredate` > date_add(curdate(), interval -3 month) 
		AND `callsign` NOT LIKE '%/sk%' 
		AND `arrlmember`=\"no\" ";
$res = $pdo->query($query);
$row_count = $res->rowCount();
// do the arithmetic...
$non_members = $row_count;
$total = $arrl_members + $non_members;
$perc = round(($arrl_members / $total) * 100);

// publish the stats

print "<table width=50%>";
print "<tr> <td colspan=3 align=center><b>Summary Report</b><br /><br />ARRL members<br />$arrl_members<br /><br />Non-members<br />$non_members<br /><br />Total membership<br />$total<br /><br /><br />$perc % of NARS members are also ARRL members<br /></td></tr>";
print "</table</>";
