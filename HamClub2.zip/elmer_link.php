<?php
include 'include/functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// print_r($_GET);  // for all GET variables
$elmr_idx = isset($_GET['position_id'])? $_GET['position_id']: 'elmr_idx not passed '; 
$mbr_idx = isset($_GET['member_id'])? $_GET['member_id']: 'mbr_idx not passed ';

echo "updating elmer ";
echo $elmr_idx;
echo " with member # ";
echo $mbr_idx;

if (isset($_GET['member_id'])) {
    if (isset($_GET['position_id'])) {

        // Update the record
	$query = "UPDATE elmers SET member_id = $mbr_idx  WHERE elmer_id = $elmr_idx";
	$stmt = $pdo->prepare($query);
        $res = $pdo->query($query);
	$msg = 'Updated Successfully!';
    }
} else {
    exit('No ID specified!');
}
?>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php endif; ?>
<a href="elmers.php">Press to continue...</a>

<?=template_header('Updating elmer information')?>

