<?php
include 'include/functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// Check if POST data is not empty
if (!empty($_POST)) {
    // Post data not empty insert a new record
    // Set-up the variables that are going to be inserted, check if the POST variables exist, if not default them to blank
    $member_id = isset($_POST['member_id']) && !empty($_POST['member_id']) && $_POST['member_id'] != 'auto' ? $_POST['member_id'] : NULL;

    // Check if POST variables exist, if not default the value to something reasonable
        $forename = isset($_POST['forename']) ? $_POST['forename'] : '';
        $surname = isset($_POST['surname']) ? $_POST['surname'] : '';
        $street = isset($_POST['street']) ? $_POST['street'] : '';
        $house = isset($_POST['house']) ? $_POST['house'] : '';
        $city = isset($_POST['city']) ? $_POST['city'] : '';
        $state = isset($_POST['state']) ? $_POST['state'] : 'TX';
        $postcode = isset($_POST['postcode']) ? $_POST['postcode'] : '';
        $country = isset($_POST['country']) ? $_POST['country'] : 'USA';
        $emailpers = isset($_POST['emailpers']) ? $_POST['emailpers'] : '';
        $emailalt = isset($_POST['emailalt']) ? $_POST['emailalt'] : '';
        $emailfail = isset($_POST['emailfail']) ? $_POST['emailfail'] :"0";
        $phonepri = isset($_POST['phonepri']) ? $_POST['phonepri'] : '';
        $phonealt = isset($_POST['phonealt']) ? $_POST['phonealt'] : '';
        $phonework = isset($_POST['phonework']) ? $_POST['phonework'] : '';
        $showdetail = isset($_POST['showdetail']) ? $_POST['showdetail'] : 'No';
        $callsign = isset($_POST['callsign']) ? $_POST['callsign'] : '';
        $licclass = isset($_POST['licclass']) ? $_POST['licclass'] : '';
        $arrlmember = isset($_POST['arrlmember']) ? $_POST['arrlmember'] : 'Yes';
        $joindate = isset($_POST['joindate']) ? $_POST['joindate'] : '2020-01-01';
        $expiredate = isset($_POST['expiredate']) ? $_POST['expiredate'] : '2021-01-01';
        $duesdate = isset($_POST['duesdate']) ? $_POST['duesdate'] : '2020-12-31';
        $membertype = isset($_POST['membertype']) ? $_POST['membertype'] : '';
        $newsdist = isset($_POST['newsdist']) ? $_POST['newsdist'] : '';
        $duesamount = isset($_POST['duesamount']) ? $_POST['duesamount'] : '20.00' ;
        $payment_by = isset($_POST['payment_by']) ? $_POST['payment_by'] : '0.00';
        $duesreceived = isset($_POST['duesreceived']) ? $_POST['duesreceived'] : '20.00';
        $notes = isset($_POST['notes']) ? $_POST['notes'] : ''; 

    // Insert new record into the members table
  	$stmt = $pdo->prepare('INSERT INTO members(member_id, forename, surname, street, house, city, state, postcode, country, emailpers, emailalt, 
			emailfail, phonepri, phonealt, phonework, showdetail, callsign, licclass, arrlmember, joindate, expiredate, 
                        duesdate, membertype, newsdist, duesamount, payment_by, duesreceived, notes) VALUES
			(:member_id, :forename, :surname, :street, :house, :city, :state, :postcode, :country, :emailpers, :emailalt, :emailfail, 
                        :phonepri, :phonealt, :phonework, :showdetail, :callsign, :licclass, :arrlmember, :joindate, :expiredate, 
                        :duesdate, :membertype, :newsdist, :duesamount, :payment_by, :duesreceived, :notes)');

	$stmt->execute([$member_id, $forename, $surname, $street, $house, $city, $state, $postcode, $country, $emailpers, $emailalt, $emailfail, 
			$phonepri, $phonealt, $phonework, $showdetail, $callsign, $licclass, $arrlmember, $joindate, $expiredate, 
			$duesdate, $membertype, $newsdist, $duesamount, $payment_by, $duesreceived, $notes]);
    // Output message
echo 'To send an acknowledgement, go to the <a href="#bottom">bottom of the page.</a>';
    $msg = 'Member Added Successfully!';
// send thanks email prompt 

}
?>
<?=template_header('Add Member')?>

<div class="content update">
	<h2>Add Member</h2>
	<br>* indicates required field
    <form action="create.php" method="post">
        <input type="hidden" name="id" placeholder="26" value="auto" id="id">
        <label for="forename">First Name *</label>
        <label for="surname">Last Name *</label>
          <input type="text" name="forename" placeholder="John" id="forename" required>
          <input type="text" name="surname" placeholder="Smith" id="surname" required>
        <label for="sreet">Street address</label>
        <label for="house">Apt / PO Box</label>
          <input type="text" name="street" placeholder="1600 Pennsylvania Ave." id="street">
          <input type="text" name="house" placeholder="" id="house">
        <label for="city">City</label>
        <label for="state">State</label>
          <input type="text" name="city" placeholder="Austin" id="city">
          <input type="text" name="state" placeholder=" TX" id="state">
        <label for="postcode">Postal code</label>
        <label for="country">Country</label>
          <input type="text" name="postcode" placeholder="78701" id="postcode">
          <input type="text" maxlength='10' name="country" placeholder="USA" value="USA" id="country">
        <label for="emailpers">Personal email *</label>
        <label for="emailalt">Alternate email</label>
          <input type="text" name="emailpers" placeholder="johndoe@example.com" id="emailpers" required>
          <input type="text" name="emailalt" placeholder="johndoe@example.com" id="emailalt">
        <label for="emailfail">Email failed</label>
          <input type="text" maxlength='3' name="emailfail" list="fail" value="No" id="emailfail" />
	  <datalist id="fail">
		<option>No</option>
		<option>Yes</option>
		</datalist>
        <label for="phonepri">Preferred phone #</label>
        <label for="phonealt">Alternate Phone #</label>
          <input type="text" name="phonepri" placeholder="5123058524" id="phonepri">
          <input type="text" name="phonealt" placeholder="5124634630" id="phonealt">
        <label for="phonework">Work phone</label>
        <label for="showdetail">Show personal details</label>
          <input type="text" name="phonework" placeholder="5124630063" id="phonework">
	  <input type="text" maxlength='3' name="showdetail" list="detail" value="No" id="showdetail">
		<datalist id="detail">
		<option>No</option>
		<option>Yes</option>
		</datalist>	
	<label for="callsign">Callsign</label>
        <label for="licclass">License class</label>
          <input type="text" name="callsign" placeholder="W5NC" id="callsign">
	  <input type="text" name="licclass" list="licl" id="licclass">
		<datalist id="licl">
		<option>Technician</option>
		<option>General</option>
		<option>Extra</option>
		<option>Novice</option>
		<option>Technician Plus</option>
		<option>Advanced</option>
		</datalist>	
        <label for="arrlmember">ARRL Member</label>
	<label for="joindate">Date joined *</label>
	  <input type="text" name="arrlmember" value="Yes" list="arrl" id="arrlmember">
		<datalist id="arr<a id="bottom">&nbsp;</a>
<a href="#top">Return to top of page.</a>l">		
		<option>Yes</option>
		<option>No</option>
		</datalist>	
	  <input type="date" name="joindate" value="<?php echo date('Y-m-d'); ?>" id="joindate" required>
        <label for="expiredate">Membership expires *</label>
	<label for="duesdate">Renewed on *</label></br>
          <input type="date" name="expiredate" value="<?php echo date('Y-m-d', strtotime('+1 year')); ?>" id="expiredate" required>
	  <input type="date" name="duesdate" value="<?php echo date('Y-m-d'); ?>" id="duesdate" required>
	<label for="membertype">Membership type</label>
	<label for="newsdist">Newsletter distribution preference</label>
	  <input type="text" name="membertype" placeholder="Member" list="mtype" id="membertype">
		<datalist id="mtype">		
		<option>Member</option>
		<option>Family</option>
		<option>Student</option>
		<option>Life</option>
		<option>Courtesy</option>
		<option>Other</option>		
		</datalist>	
	  <input type="text" name="newsdist" placeholder="Web" list="news" id="newsdist">
		<datalist id="news">		
		<option>Web</option>
		<option>Email</option>
		<option>Mail</option>
		</datalist>	
	<label for="duesamount">Dues</label>
	<label for="payment_by">Payment by</label>
          <input type="number" name="duesamount" value="20.00" min="00.00" step="5.00" id="duesamount">
	  <input type="text" name="payment_by" placeholder="PayPal" list="pmtby" id="payment_by">
		<datalist id="pmtby">		
		<option>PayPal</option>
		<option>Check</option>
		<option>Cash</option>
		<option>Zelle</option>
		</datalist>	
	<label for="duesreceived">Dues received</label>
	<label for="notes">Notes</label>
          <input type="number" name="duesreceived" value="20.00" min="0" step="5.0" id="duesreceived">
          <input type="text" name="notes" placeholder="" id="notes">

        <input type="submit" value="Create">
	</form>
    <?php if ($msg) include 'new_member_welcome.php';?>
</div>
<a id="bottom">&nbsp;</a>
<a href="#top">Return to top of page.</a>
<?=template_footer()?>
