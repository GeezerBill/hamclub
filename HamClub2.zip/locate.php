<?php
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Get the page via GET request (URL param: page), if non exists default the page to 1
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
// Number of records to show on each page
$records_per_page = 10;
// Prepare the SQL statement and get records from our members table, LIMIT will determine the page
// adapted from original hamclub...
if (isset($_REQUEST['filter'])) {
    $filter = $_REQUEST['filter'];
} else {
    $filter = null;
}

// Start build the query...
$query = "SELECT * FROM members WHERE 
			surname LIKE '%$filter[lastname]%' and
			callsign LIKE '%$filter[call]%' and
			state LIKE '%$filter[st]%' and 
			postcode LIKE '%$filter[zipcode]%' and 
			expiredate LIKE '%$filter[expires]%'
	ORDER BY surname, forename LIMIT :current_page, :record_per_page";

$stmt = $pdo->prepare($query);
$stmt->bindValue(':current_page', ($page - 1) * $records_per_page, PDO::PARAM_INT);
$stmt->bindValue(':record_per_page', $records_per_page, PDO::PARAM_INT);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of members, this is so we can determine whether there should be a next and previous button
$num_members = $pdo->query('SELECT COUNT(*) FROM members')->fetchColumn();
?>
<?=template_header('Update') ?>
<div class="content read">
<table>
<form action="<?php print $_SERVER['PHP_SELF']; ?>" method="post">
	<tr><br>To search the list, enter one or more details in the search boxes below. Partial entries will find those characters anywhere in the field. For example, 2021 in the <b>Expires</b> field returns all memberships expiring in 2021.<br>
	</tr>
	<tr>
		<td><label for="lastname">Last Name</label></td>
		<td><label for="zipcode">ZIP code</label></td>
		<td><label for="st">State</label></td>
	</tr>
	<tr>
		<td><input type="text" name="filter[lastname]" value="<?php print $filter['lastname']; ?>"></td>
		<td><input type="text" name="filter[zipcode]" value="<?php print $filter['zipcode']; ?>"></td>
		<td><input type="text" name="filter[st]" value="<?php print $filter['st']; ?>"></td>
	</tr>
	<tr>
		<td><label for="call">Call</label></td>
		<td><label for="expires">Membership expires</label></td>
		<td><label for="search">Search</label></td>
	</tr>
	<tr>
		<td><input type="text" name="filter[call]" value="<?php print $filter['call']; ?>"></td>
		<td><input type="text"name="filter[expires]" value="<?php print $filter['expires']; ?>"></td>
		<td><input type="hidden" name="limit" value="0"> 
			<input type="submit" name="search" value="Press to search"></td>
	</tr>
</table>

	<h2>Update members</h2>
	<table>
        <thead>
            <tr>
                <td>#</td>
                <td>First name</td>
                <td>Last name</td>
                <td>Call</td>
                <td>Phone</td>
                <td>Email</td>
                <td>Expires on</td>
                <td>Select</td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
            <tr>
                <td><?=$member['member_id'] ?></td>
                <td><?=$member['forename'] ?></td>
                <td><?=$member['surname'] ?></td>
                <td><?=$member['callsign'] ?></td>
                <td><?=$member['phonepri'] ?></td>
                <td><?=$member['emailpers'] ?></td>
                <td><?=$member['expiredate'] ?></td>
                <td class="actions">
                    <a href="update.php?member_id=<?=$member['member_id'] ?>" class="edit">Select</a>
                </td>
            </tr>
            <?php
endforeach; ?>
        </tbody>
    </table>
	<div class="pagination">
		<?php if ($page > 1): ?>
		<a href="locate.php?page=<?=$page - 1 ?>"><i class="fas fa-angle-double-left fa-sm"></i></a>
		<?php
endif; ?>
		<?php if ($page * $records_per_page < $num_members): ?>
		<a href="locate.php?page=<?=$page + 1 ?>"><i class="fas fa-angle-double-right fa-sm"></i></a>
		<?php
endif; ?>
</div>
</div>
<?=template_footer() ?>

