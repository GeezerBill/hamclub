<?php
include 'include/functions.php';
$file_name = "email_body/renewal_notice.txt";
($message_file = fopen($file_name, "r")) or die("Unable to open file!");
$message = fread($message_file, filesize($file_name));

$pdo = pdo_connect_mysql();
    // Get the contact from the members table
    $stmt = $pdo->prepare('SELECT * FROM members WHERE member_id = ?');
    $stmt->execute([$_GET['member_id']]);
    $member = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$member) 
        exit('Contact doesn\'t exist with that ID!');


// tell who the message is going to
$email = $member['emailpers'];
$first_name = $member['forename'];
$hamcall = $member['callsign'];
$expiredate = $member['expiredate'];
$pmt_amount = $member['duesamount'];
$ccemail = 'officers@w5nc.net';
$subj = 'Membership renewal request for '.' '.$hamcall;
$crlf = '%0D%0A';
$current_date = date("l, d M Y");
$addr_head = 'Northwest Amateur Radio Society%0D%0AP.O. Box 11483%0D%0ASpring, Texas 77391';
$mast_head = $current_date.$crlf.$addr_head.$crlf;
$pre = 'Hello '.$first_name.' ('.$hamcall.'):'.$crlf;
// tell who the message is going to

$pre =
    "Hello " .
    $first_name .
    " (" .
    $hamcall .
    "):" .
    $crlf .
    "Your membership expires on " .
    $expiredate .
    ". ";
$fixed_body = htmlspecialchars($message);
$msg_body = $mast_head . $crlf . $pre . $crlf . $fixed_body;

echo <<<EOL
                    
<a href="mailto:$email?cc=$ccemail&subject=$subj&body=$msg_body">Send renewal notice to $first_name</a>
<br>
<a href="renew_bulk.php">Continue...</a>
EOL;
fclose($message_file);
?>


