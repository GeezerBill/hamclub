<?php
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Get the page via GET request (URL param: page), if non exists default the page to 1
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
// Number of records to show on each page
$records_per_page = 75;

// Prepare the SQL statement and get records from our members table, LIMIT will determine the page
$query="SELECT * FROM members WHERE `expiredate` < NOW() + INTERVAL 2 month
				AND `expiredate`> NOW() + INTERVAL -3 month
				AND `callsign` NOT LIKE '%/sk%'
	                        ORDER BY surname,forename
				LIMIT :current_page, :record_per_page";

$stmt = $pdo->prepare($query);
$stmt->bindValue(':current_page', ($page-1)*$records_per_page, PDO::PARAM_INT);
$stmt->bindValue(':record_per_page', $records_per_page, PDO::PARAM_INT);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of members, this is so we can determine whether there should be a next and previous button
$query="SELECT COUNT(*) FROM members WHERE `expiredate` < NOW() + INTERVAL 2 month
				AND `expiredate`> NOW() + INTERVAL -3 month
				AND `callsign` NOT LIKE '%/sk%'";
$num_members = $pdo->query($query)->fetchColumn();
$mail_list = []; //collect the email addresses here
template_header('Membership Renewal');
?>
<div class="content read">
	<h2>Membership Renewal</h2>
		<body><p>The memberships listed below have expired within the past three months or are expiring during the next two months. Click the <b>Individual</b> link to create an email reminder to that person, and then click <b>SEND</b> in your email client.</p><p>Click the <b>Update</b> link to update the information for that member.</p></body>
	<table>
        <thead>
            <tr> 
                <td>#</td>
		<td>Call</td>
                <td>First name</td>
                <td>Last name</td>
                <td>Email</td>
                <td>Membership expires</td>
		<td>Update</td>
                <td>Renewal notice</td>
            </tr>
        </thead>
        <tbody>
       <?php $num = 0; ?>     
	<?php foreach ($members as $member): ?>
            <tr><?php $num = array_unshift($mail_list, $member['emailpers']); ?>
                <td><?=$member['member_id']?></td>
		<td><?=$member['callsign']?></td>
                <td><?=$member['forename']?></td>
                <td><?=$member['surname']?></td>
                <td><?=$member['emailpers']?></td>
                <td><?=$member['expiredate']?></td>
                <td class="actions"><a href="update.php?member_id=<?=$member['member_id'] ?>" class="edit">Update</a></td>              
                <td class="actions"><a href="renewal_notice_individual.php?member_id=<?=$member['member_id'] ?>" class="edit">Renew Notice</a></td> 

            </tr>
<tr>           
<?php endforeach; 
// build the header....
$ccemail = 'officers@w5nc.net';
$subj = date ("Y") . ' Membership renewal request';
$crlf = '%0D%0A';
$current_date = date("l, d M Y");
$addr_head = 'Northwest Amateur Radio Society%0D%0AP.O. Box 11483%0D%0ASpring, Texas 77391';
$mast_head = $current_date.$crlf.$addr_head.$crlf;
$recipients = implode (' ,', $mail_list);
$pre = 'Hello fellow NARS member' . $crlf;
// get the message body
$file_name = "email_body/renewal_notice.txt";
($message_file = fopen($file_name, "r")) or die("Unable to open file!");
$message = fread($message_file, filesize($file_name)); 
fclose($message_file);
// clean and assemble the message body
$fixed_body = 'Your membership in NARS is expiring soon or has expired.%0A%0A' . htmlspecialchars($message);
$msg_body = $mast_head . $crlf . $pre . $crlf . $fixed_body;
?>
<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
<td class="actions"><a href="mailto:?cc=<?=$ccemail?>&bcc=<?=$recipients?>&subject=<?=$subj?>&body=<?=$msg_body?>" class="edit">Bulk</a></td>
</tr>
<tr><p>Click the <b>Bulk</b> link at the bottom of the list to send an email reminder to all <?=$num?> members on this page, and then click <b>SEND</b> in your email client.</p></body></tr>
<tr>      
</tbody>
    </table>
        <div class="pagination">
                <?php if ($page > 1): ?>
                <a href="renew_bulk.php?page=<?=$page-1?>"><i class="fas fa-angle-double-left fa-sm"></i></a>
                <?php endif; ?>
                <?php if ($page*$records_per_page < $num_members): ?>
                <a href="renew_bulk.php?page=<?=$page+1?>"><i class="fas fa-angle-double-right fa-sm"></i></a>
                <?php endif; ?>
        </div>
</div>

