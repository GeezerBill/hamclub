<?php
// updated for PDO access July 2014 web
// displays record for selected member on w5nc
// updated January 2018 - supress detail listing for 
// selected members, depending on state of field 'showdetail'
// showdetail field added to database January 2018
// 'Do not display' message added member info popup  
// March 2018

include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();

$id=$_REQUEST['id'];
$query = ("SELECT * FROM members WHERE member_id=$id");

$res = $pdo->query($query);
$row = $res->fetch(PDO::FETCH_NUM);

print "<!DOCTYPE html>";
print "<html>";
print "<head>";
print "<title>NARS Member Contact Information</title>";
print "</head>";
print "<body>";

// check showdetail/no show flag... - query result indexed from 0...
if ($row[15]<>'no')

{
print "<h1>Contact information for:</h1>";

print "<body>";
print "<p style='color:brown'>";
for ($key=1; $key < count($row); $key++) {
// skip the id #
switch ($key) {
    case 1:
	print "$row[$key] &nbsp;";
        break;
    case 2:
	print "$row[$key] <br>";
        break;
    case 3: //street
	if (!empty ($row[$key])) {print "$row[$key] <br>";}
        break;
    case 4: //house
        if (!empty ($row[$key])) {print "$row[$key] <br>";}
        break;
    case 5: //city
        if (!empty ($row[$key])) {print "$row[$key]";}
        break;
    case 6: //state
        if (!empty ($row[$key])) {print ", &nbsp; $row[$key]";}
        break;
    case 7: //post code
	if (!empty ($row[$key])) {print "&nbsp; &nbsp; $row[$key] <br>";}
        break;
    case 8: //country
	print "$row[$key] <br>";
        break;
    case 9: //primary email
	if (!empty ($row[$key])) {print "Preferred email: $row[$key] <br>";}
        break;
    case 10: // alternate email
	if (!empty ($row[$key])) {print "Alternate email: $row[$key] <br>";}
        break;
    case 12:
	if (!empty ($row[$key])) {print "Preferred phone: $row[$key]<br>";}
        break;
    case 13:
        if (!empty ($row[$key])) {print "Alternate phone: $row[$key]<br>";}
        break;
    case 14:
        if (!empty ($row[$key])) {print "Work phone: $row[$key]<br>";}
        break;
    case 16:
        if (!empty ($row[$key])) {print "Call: $row[$key]<br>";}
        break;
}}

print "</p><br>";
echo "If you prefer not to display the information above, please email your request to</br>";
echo "<a href='mailto:webmaster@w5nc.net ?subject=$row[16]&body=do%20not%20display'>webmaster@w5nc.net</a></br>";
echo "with your call in the subject line and 'do not display' in the body</br>";
} else
{
echo "<h1>Contact information not available</h1>";
}
print "</body>";
print "</html>";
//pdo close connection

?>
