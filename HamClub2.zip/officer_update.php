<?php
session_start();
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Get the page via GET request (URL param: page), if non exists default the page to 1

//capture the position we are working on...
$position_id = isset($_GET['officer_id']) ? $_GET['officer_id'] : 1;
//  second pass with one member selected...
if (isset($_SESSION['position_id'])) {
$position_id = $_SESSION['position_id'];
}
// this code could benefit from cleanup, but it works as intended for now
$_SESSION['position_id'] = $position_id;

//extract the position text...
$query = "SELECT * FROM `officers` WHERE `officer_id` = $position_id";
$res = $pdo->query($query);
$row = $res->fetch(PDO::FETCH_NUM);
$position = $row[1];
//
if (isset($_REQUEST['filter'])) {
	$filter = $_REQUEST['filter'];
} else {
	$filter = null;
}
// build the member query...
$query = "SELECT * FROM members WHERE 
	surname LIKE '%$filter[lastname]%' 
	AND callsign LIKE '%$filter[call]%' 
	AND `callsign` NOT LIKE '%/sk%'
	AND `expiredate`> NOW()
	ORDER BY surname";

$stmt = $pdo->prepare($query);

$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of members, this is so we can determine whether there should be a next and previous button
$num_members = $pdo->query('SELECT COUNT(*) FROM members')->fetchColumn();
?>
<?=template_header('Officer Update') ?>

<div class="content read">

<h2>Select member for <?php echo $position ?></h2>

<table>
<form action="<?php print $_SERVER['PHP_SELF'] ?>" method="get">

	<tr><br>To search the list, enter one or more details in the search boxes below. Partial entries will find those characters anywhere in the field.<br>
	</tr>
	<tr>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><label for="lastname">Last Name</label></td>
		<td><label for="call">Call</label></td>
		<td><label for="search">Search</label></td>
	</tr>
	<tr>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><input type="text" name="filter[lastname]" value="<?php print $filter['lastname'];?>"></td>
		<td><input type="text" name="filter[call]" value="<?php print $filter['call'];?>"></td>
		<td><input type="hidden" name="limit" value="0"> 
		    <input type="submit" name="search" value= "Press to search" </td>
	</tr>
</table>
	<p>To complete the assignment, click the note icon in the <b>Update</b> column that corresponds to row of the member you are assigning to the position.</p>
	<table>
        <thead>
            <tr>
                <td>#</td>
                <td>First name</td>
                <td>Last name</td>
                <td>Call</td>
                <td>Phone</td>
                <td>Email</td>
                <td>Expires on</td>
                <td>Update</td>
            </tr>
        </thead>
        <tbody>
            <?php
foreach ($members as $member):?>
            <tr>
                <td><?=$member['member_id'] ?></td>
                <td><?=$member['forename'] ?></td>
                <td><?=$member['surname'] ?></td>
                <td><?=$member['callsign'] ?></td>
                <td><?=$member['phonepri'] ?></td>
                <td><?=$member['emailpers'] ?></td>
                <td><?=$member['expiredate'] ?></td>
                <td class="actions">
                    <a href="officer_link.php?member_id=<?=$member['member_id']?> & position_id=<?=$position_id?>" class="edit">Update</a>
                </td>
            </tr>
            <?php
endforeach;
?>
        </tbody>
    </table>
</div>
<?=template_footer() ?>
