<?php
include 'include/functions.php';
// Connect to MySQL database
$pdo = pdo_connect_mysql();
// Get the page via GET request (URL param: page), if non exists default the page to 1
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
// Number of records to show on each page
$records_per_page = 75;
$num = 0;
// Prepare the SQL statement and get records from our members table, LIMIT will determine the page
$query="SELECT * FROM members WHERE `expiredate`> NOW() + INTERVAL -3 month
				AND `callsign` NOT LIKE '%/sk%'
	                        ORDER BY surname,forename
				LIMIT :current_page, :record_per_page";
$stmt = $pdo->prepare($query);
$stmt->bindValue(':current_page', ($page-1)*$records_per_page, PDO::PARAM_INT);
$stmt->bindValue(':record_per_page', $records_per_page, PDO::PARAM_INT);
$stmt->execute();
// Fetch the records so we can display them in our template.
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Get the total number of members, this is so we can determine whether there should be a next and previous button
$query="SELECT COUNT(*) FROM members WHERE `expiredate`> NOW() + INTERVAL -3 month
				AND `callsign` NOT LIKE '%/sk%'";
$num_members = $pdo->query($query)->fetchColumn();
$renew_list = []; //collect renewal email addressses here
?>
<?=template_header('Email blast')?>
<a id="top">&nbsp;</a>
<div class="content read">
	<h2>Membership Email Blast</h2>
	</body><p>To send email to all club members, click the <b>BULK</b> link at the <a href="#bottom">bottom of the page</a>. Navigate to the next page with the arrows and repeat as needed.</p> <p>Click the <b>Individual</b> link to create an email for only that member. Edit the body of the email as necessary. Click <b>SEND</b> in your email client to send the email.</p>
	<table>
        <thead>
            <tr> 
                <td>#</td>
		<td>Call</td>
                <td>First name</td>
                <td>Last name</td>
                <td>Email</td>
                <td>Membership expires</td>
                <td>Send email</td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
            <tr><?php $num = array_unshift($renew_list, $member['emailpers']); ?>
                <td><?=$member['member_id']?></td>
		<td><?=$member['callsign']?></td>
                <td><?=$member['forename']?></td>
                <td><?=$member['surname']?></td>
                <td><?=$member['emailpers']?></td>
                <td><?=$member['expiredate']?></td>
                <td class="actions">
                    <a href="mailto:<?=$member['emailpers']?>?subject=message%20from%20the%20officers%20<?=$member['callsign']?>&Body=Hello%20<?=$member['forename']?>&body=Update%20from%20your%20board...%0A73%2C%0ANARS%20Officers" class="edit">Individual</a>
                </td>
            </tr>
<tr>
<?php 
endforeach; 
$recipients = implode (", ", $renew_list); 
?>

<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
<td class="actions"><a href="mailto:?bcc=<?=$recipients?>&subject=message%20from%20the%20officers&body=Update%20from%20your%20board...%0A73%2C%0ANARS%20Officers" class="edit">Bulk</a></td>
</tr>     
</tbody>
    </table>
        <div class="pagination">
                <?php if ($page > 1): ?>
                <a href="email_blast_bulk.php?page=<?=$page-1?>"><i class="fas fa-angle-double-left fa-sm"></i></a>
                <?php endif; ?>
                <?php 
		if ($page*$records_per_page < $num_members): ?>
                <a href="email_blast_bulk.php?page=<?=$page+1?>"><i class="fas fa-angle-double-right fa-sm"></i></a>
                <?php endif; ?>
        </div>
<a id="bottom">&nbsp;</a>
<a href="#top">Return to top of the page</a>
</div>
<?=template_footer('footer')?>
